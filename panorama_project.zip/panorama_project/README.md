# 🖼️ Panorama Image Stitcher

A production-quality panorama stitching application built with **Python, OpenCV, and Streamlit**. Upload two or more overlapping photos of the same scene and get back a seamless, automatically-cropped panorama — comparable to the panorama mode on a modern smartphone.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Features](#features)
3. [Folder Structure](#folder-structure)
4. [Installation](#installation)
5. [Running the App](#running-the-app)
6. [Command-Line Interface](#command-line-interface)
7. [How It Works (Algorithm)](#how-it-works-algorithm)
8. [Configuration Options](#configuration-options)
9. [Error Handling](#error-handling)
10. [Screenshots](#screenshots)
11. [Limitations](#limitations)
12. [Future Improvements](#future-improvements)

---

## Project Overview

This project implements a full panorama-stitching pipeline from first principles using classical computer vision (no deep learning required):

`Feature Detection → Feature Matching → Homography Estimation (RANSAC) → Warping → Exposure Compensation → Blending → Auto-Cropping`

It ships with:
- A **Streamlit web UI** (`app.py`) with drag-and-drop upload, live progress, debug visualizations, an interactive zoom/pan panorama viewer, and one-click download.
- A **command-line interface** (`cli.py`) for scripted / batch use.
- A clean, modular codebase (`stitcher.py`, `feature_matching.py`, `blending.py`, `utils.py`) that is easy to read, extend, and test independently of the UI.

---

## Features

**Core requirements**
- ✅ Upload 2+ images (JPG / JPEG / PNG) with thumbnail previews
- ✅ SIFT feature detection (auto-falls back to ORB if SIFT is unavailable)
- ✅ BFMatcher (ORB) / FLANN (SIFT) matching + Lowe's ratio test
- ✅ Homography estimation with `cv2.findHomography` + RANSAC
- ✅ Perspective warping onto a shared canvas (`cv2.warpPerspective`)
- ✅ Seamless blending — **multi-band (Laplacian pyramid)** or **feather** blending
- ✅ Automatic detection & cropping of black borders
- ✅ Modern UI: upload button, stitch button, progress bar, status log, preview, download button
- ✅ Robust error handling with user-friendly messages

**Bonus features implemented**
- ✅ Automatic image ordering (no need to upload in left-to-right order)
- ✅ Cylindrical projection (optional, for wide rotational panoramas)
- ✅ Simple exposure/brightness compensation between overlapping images
- ✅ Progress indicator with live status log
- ✅ Drag-and-drop upload (native to Streamlit's file uploader)
- ✅ Interactive zoom & pan viewer for the final panorama (scroll to zoom, drag to pan)
- ✅ Debug mode: view feature-match visualizations and intermediate warped images
- ✅ Save intermediate debug images to disk (`outputs/debug/`)
- ✅ Batch panorama generation via CLI (`--batch-input`)
- ✅ Full command-line interface
- ✅ Graceful GPU/CUDA detection (`utils.cuda_available` equivalent check) with automatic CPU fallback if CUDA isn't present in the OpenCV build

---

## Folder Structure

```
panorama_project/
│
├── app.py                # Streamlit web application (UI)
├── stitcher.py            # Core pipeline: PanoramaStitcher orchestration class
├── feature_matching.py     # Feature detection (SIFT/ORB) + matching + Lowe's ratio test
├── blending.py            # Feather blending & multi-band (Laplacian pyramid) blending
├── utils.py               # Validation, cropping, cylindrical warp, exposure comp, I/O helpers
├── cli.py                 # Command-line interface (single + batch modes)
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── sample_images/           # Example overlapping images to try the app with
└── outputs/                 # Default location for saved panoramas & debug images
```

---

## Installation

### 1. Prerequisites
- Python 3.9+
- pip

### 2. Clone / copy the project
Place all files in a folder named `panorama_project/` (matching the structure above).

### 3. Create a virtual environment (recommended)

**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows**
```bash
python -m venv venv
venv\Scripts\activate
```

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

`requirements.txt` includes:
```
opencv-contrib-python>=4.8.0
numpy>=1.24.0
streamlit>=1.32.0
Pillow>=10.0.0
scikit-image>=0.22.0
```

> **Note:** `opencv-contrib-python` (not plain `opencv-python`) is required so that `cv2.SIFT_create()` is available. If SIFT cannot be created for any reason, the app automatically falls back to ORB — no code changes needed.

---

## Running the App

From inside the `panorama_project/` folder:

```bash
streamlit run app.py
```

This opens the app in your browser (default: `http://localhost:8501`). Then:

1. **Upload** 2 or more overlapping JPG/PNG images.
2. Adjust options in the sidebar if desired (blending method, cylindrical projection, exposure compensation, debug mode, working resolution).
3. Click **🧵 Stitch Panorama**.
4. Watch the progress bar and status log.
5. Explore the result: feature-match debug view (if enabled), the warped images before blending, and the final panorama in the interactive zoom/pan viewer.
6. Click **⬇️ Download Panorama (PNG)** to save it.

---

## Command-Line Interface

Stitch a single folder of images:
```bash
python cli.py --input sample_images --output outputs/panorama.png
```

Batch mode — every sub-folder of `--batch-input` becomes its own panorama:
```bash
python cli.py --batch-input path/to/many_scenes/ --output-dir outputs/
```

Useful flags:
```
--blend {multiband,feather}     Blending method (default: multiband)
--cylindrical                   Enable cylindrical projection
--no-exposure-comp              Disable brightness/exposure compensation
--no-auto-order                 Stitch images in the given (not auto-detected) order
--max-dimension INT             Max working resolution in pixels (default: 1600)
--debug                         Save intermediate feature-match debug images
```

---

## How It Works (Algorithm)

1. **Pre-processing** — Images are resized so their largest dimension does not exceed a configurable limit (keeps runtime reasonable). Optionally, each image is projected onto a **cylindrical surface** to reduce perspective distortion for wide, rotation-based panoramas.

2. **Feature Detection** — For every image, keypoints and descriptors are extracted using **SIFT** (scale/rotation invariant, sub-pixel accurate). If the installed OpenCV build lacks SIFT, the pipeline transparently switches to **ORB** (fast, binary descriptors, patent-free).

3. **Automatic Ordering** *(optional)* — When more than 2 images are uploaded, a pairwise "good match count" matrix is built between every pair of images. A chain is grown greedily from the strongest pair outward, so the images end up in a sensible left-to-right stitching order regardless of upload order.

4. **Feature Matching** — Descriptors between adjacent images (in stitching order) are matched with **FLANN** (for SIFT's float descriptors) or **BFMatcher with Hamming distance** (for ORB's binary descriptors). **Lowe's ratio test** (default threshold 0.75) discards ambiguous matches, keeping only distinctive, reliable correspondences.

5. **Homography Estimation** — `cv2.findHomography()` with **RANSAC** computes the 3×3 projective transform between each adjacent image pair, automatically rejecting outlier matches. The inlier ratio is reported so you can judge match quality.

6. **Homography Chaining** — Rather than warping everything relative to one edge image (which maximizes distortion), all per-pair homographies are composed into a single **reference frame anchored at the middle image**, minimizing cumulative geometric distortion across the panorama.

7. **Canvas Computation & Warping** — The transformed corners of every image are used to compute the bounding box of the final canvas and a translation that keeps all coordinates positive. Each image is then warped onto this shared canvas with `cv2.warpPerspective()`.

8. **Exposure Compensation** *(optional)* — Before blending each new image in, its brightness is compared to the already-built panorama in their overlapping region, and a clamped gain correction is applied so that stitched photos taken in slightly different lighting don't produce a visible brightness seam.

9. **Blending** — Two strategies are available:
   - **Feather blending**: per-pixel weights derived from a distance transform (how far a pixel is from the edge of its image's content), producing a smooth linear cross-fade in the overlap region.
   - **Multi-band (Laplacian pyramid) blending**: images are decomposed into Gaussian/Laplacian pyramids; low frequencies (broad lighting/color) are blended over a wide region while high frequencies (texture/edges) are blended more narrowly. This avoids both hard seams and blurring/ghosting of fine detail — the technique used in most professional stitching software.

10. **Auto-Cropping** — The final canvas nearly always has ragged black borders where no image data was warped. These are automatically detected via contour analysis on a binarized non-black mask and cropped away so the output panorama is a clean rectangle of useful pixels only.

---

## Configuration Options

| Option | Where | Description |
|---|---|---|
| Blending method | Sidebar / `--blend` | `multiband` (recommended, smoothest) or `feather` (faster) |
| Cylindrical projection | Sidebar / `--cylindrical` | Reduces distortion for wide, many-image rotational panoramas |
| Exposure compensation | Sidebar / `--no-exposure-comp` | Corrects brightness differences between photos |
| Automatic ordering | Sidebar / `--no-auto-order` | Figures out left-to-right order automatically |
| Debug mode | Sidebar / `--debug` | Shows/saves feature-match visualizations |
| Max working resolution | Sidebar / `--max-dimension` | Speed/quality trade-off |

---

## Error Handling

The application gracefully detects and reports, with user-friendly messages instead of crashing:

- Fewer than 2 images uploaded
- Corrupted or unreadable image files
- Unsupported file types
- Images that don't overlap enough (too few reliable matches)
- Homography estimation failure (degenerate geometry / too few RANSAC inliers)
- Images of very different sizes (handled naturally via independent resizing before warping)

---

## Screenshots

> _Add screenshots of your running app here, e.g.:_
>
> `docs/screenshot_upload.png` — Upload screen with thumbnails
> `docs/screenshot_debug.png` — Feature-match debug view
> `docs/screenshot_result.png` — Final panorama with zoom/pan viewer

---

## Limitations

- Classical feature-based stitching struggles with **scenes lacking texture** (blank walls, clear sky) since too few reliable keypoints can be found.
- Works best for **static scenes**; moving objects (people, cars) can produce ghosting artifacts in overlap regions.
- Homography-based warping assumes either a **rotating camera** or a **planar scene** — panoramas of scenes with significant depth/parallax (close-up objects at varying distances) may show local misalignment.
- GPU acceleration depends on OpenCV being built with CUDA support; the default `opencv-contrib-python` wheel from PyPI does **not** include CUDA, so the app automatically runs on CPU. Users who build OpenCV with CUDA support can extend `feature_matching.py` to use `cv2.cuda` equivalents.
- Very large panoramas (many high-resolution images) can require significant RAM during pyramid blending; use the "Max working resolution" setting to manage this.

---

## Future Improvements

- Deep-learning-based feature matching (e.g., SuperGlue/LoFTR) for scenes with low texture or large viewpoint changes.
- Bundle adjustment across all images simultaneously (rather than sequential pairwise chaining) for large panoramas, as done in tools like Hugin/AutoStitch.
- Seam-optimal cutting (graph-cut based) prior to blending, in addition to the current feather/multi-band approaches.
- Automatic focal-length estimation for cylindrical/spherical projection instead of the current width-based heuristic.
- True GPU-accelerated feature detection/matching when CUDA-enabled OpenCV is available.
- 360° / spherical panorama support for full-rotation photo sets.

---

Built with ❤️ using Python, OpenCV, NumPy, and Streamlit.
